public class OddEven2 {

	public static void main(String[] args) {
		int num = Integer.parseInt(args[0]);
		System.out.println("Value of num is: " + num);
		if(num % 2 == 0)
		{
			System.out.println(num + " is Even Number");
		}
		else{
			System.out.println(num + " is Odd Number");
		}
	}
}
