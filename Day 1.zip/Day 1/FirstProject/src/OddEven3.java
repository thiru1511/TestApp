import java.util.Scanner;

public class OddEven3 {

	public static void main(String[] args) {
		System.out.println("Enter the value of num :");
		Scanner s = new Scanner(System.in);
		int num = s.nextInt();
		System.out.println("Value of num is: " + num);
		if(num % 2 == 0)
		{
			System.out.println(num + " is Even Number");
		}
		else{
			System.out.println(num + " is Odd Number");
		}
		s.close();
	}
	
}
