package pack1;

public class Calcy {
	public int add(int num1, int num2) {
		if(num1 < 0 || num2 < 0){
			throw new IllegalArgumentException("Negative Numbers are not allowed");
	}
		int sum = num1 + num2;
		return sum;

	}
}