package pack1.test;

import static org.junit.Assert.*;

import org.junit.Test;

import pack1.Calcy;

public class CalcyTest {

	@Test
	public void testAddShouldGiveSumOfTwoNumbers() {
		Calcy c = new Calcy();
		int result = c.add(100,300);
		assertEquals(400, result);                                                                                                                                               
	}

}
