package Library;

public class bookDemo {

	public static void main(String[] args) {
     Book book1 = new Book();
     book1.displayBook();
     
     Book book2 = new Book("Java", "Cay Horstman", 1000);
     book2.displayBook();
	}

}
