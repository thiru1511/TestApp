package Library;

public class Book1 {
	private String isbn;
	private String title;
	private String author;
	private Double price;
	
	
public Book1() {
		isbn = "Unknown";
		title = "No-title";
		author = "Budda";
		price = (double) 100;
	}
	public Book1(String isbn, String title,String author, double price){
		this.isbn = isbn;
		this.title = title;
		this.author = author;
		this.price = price;
	}

	//Member Function or Method
	public void displaydetails() {
		System.out.println("Book Name: " + isbn);
		System.out.println("Book Title: " + title);
		System.out.println("Book Author: " + author);
		System.out.println("Book Price: " + price);
	}

}
	
