package Library;

public class book1Demo {

	public static void main(String[] args) {
		 Book1 book2 = new Book1();
	     book2.displaydetails();
	}

}
