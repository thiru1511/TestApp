package Library;

public class Book {
	// Data Members
	private String bookName;
	private String bookAuthor;
	private Double bookPrice;
	
	public Book(){
		bookName = "Unknown";
		bookAuthor = "No-Author";
		bookPrice = (double) -1;
	}
	public Book(String bookName, String bookAuthor, double bookPrice){
		this.bookName = bookName;
		this.bookAuthor = bookAuthor;
		this.bookPrice = bookPrice;
	}

	//Member Function or Method
	public void displayBook() {
		System.out.println("Book Name: " +bookName);
		System.out.println("Book Author: " +bookAuthor);
		System.out.println("Book Price: " +bookPrice);
	}
}
