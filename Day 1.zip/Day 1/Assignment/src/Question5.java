import java.util.Scanner;

public class Question5 {

	public static void main(String[] args) {
		System.out.println("Enter the value of N ");
		Scanner n = new Scanner(System.in);
		int num = n.nextInt();
		int var = 1, i;
		for (i = 1; i <= num; i++) {
			var = var*i;
		}
		System.out.println("The factorial of N is " + var);
		n.close();
	}

}
