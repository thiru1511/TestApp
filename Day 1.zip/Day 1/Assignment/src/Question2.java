import java.util.Scanner;

public class Question2 {

	public static void main(String[] args) {
		System.out.print("Enter the number : ");
		Scanner n = new Scanner(System.in);
		int num = n.nextInt();
		if (num > 0) {
			System.out.println(num + " is positive");
		} else {
			System.out.println(num + " is negative");
		}
		n.close();
	}

}
