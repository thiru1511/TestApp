public class Question3 {

	public static void main(String[] args) {
		System.out.println("Enter the strings :");
		String s1 = args[0];
		String s2 = args[1];
		System.out.println(s1 + " Technologies " + s2);
	}
}
